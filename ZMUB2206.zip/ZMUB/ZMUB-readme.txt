Put into VATPRC Sector folder.

Made by Rudi Zhang(1326158), Data source Jeppesen GE Data